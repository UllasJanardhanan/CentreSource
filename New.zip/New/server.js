const express=require("express")
const mysql=require("mysql");

//const pug = require('pug');


//var exhbs=require("express-handlebars");


var app= express()
const path=require("path");
const bodyparser=require("body-parser")
var router = express.Router();
//var hbs = exhbs.create({ /* config */ });

// Register `hbs.engine` with the Express app.
//app.use(express.static(path.join(__dirname, 'public')));

/*app.set('views',path.join(__dirname,'views'))
app.engine('handlebars', hbs.engine);
app.set('view engine', 'handlebars');*/
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'pug');





//newly added
app.use(
    express.urlencoded({
      extended: true
    })
  );

 

//end
app.use(bodyparser.json())
app.use(bodyparser.urlencoded({     // to support URL-encoded bodies
    extended: true
  })); 


const { query, Router } = require("express");
const { get } = require("http");
const { isBuffer } = require("util");


var mysqlConnection =mysql.createConnection({
    host:'localhost',
    user:'root',
    password:'123456',
    database:'db1',
    });



mysqlConnection.connect((err)=>{
    if(err)
        {
            console.log("Not Connected ")

        }
    else{
        console.log("Database Connected")
        }
});


app.get('/SubCategories',function(req,res,next){
   // {
     //   res.render('index');
        //res.sendFile(path.join(__dirname,"form.html"))
    //}



    //res.sendFile(path.join(__dirname,'form.html'))
//newlyadded
mysqlConnection.query("select * from categories",function(err,data,field){
    if (err) throw(err);
   // else console.log(data);
   else
   {

    //console.log(data);
    //var option = "";
    //for(var i=0; i<data.length; i++)
    //{
     //   console.log(data[i].CatName);
      //  console.log(data[i].CatId);
        
       // option+= '<option value="'+ data[i].CatId +'">' + data[i].CatName + "</option>"
      
    //}

    res.render("SubCategories",{opt:data})
    
   
   }
    // res.render('form', { dropdownVals: data.recordset })
    
})
//end
})
//app.post('/formaction',function(req,res){
      
  //  res.send("Product Added")
//})


app.post('/SubCategories',(req,res)=>{

    //var e = document.getElementById("catlist");
   // var result = e.options[e.selectedIndex].value;
    //console.log(result);
    //console.log(value);
  var CatId=req.body.catlist;

   var subcatName=req.body.SubCat;
        
  console.log(CatId);
  console.log(subcatName);
           // var subCatName=req.body.SubCategoryName


           mysqlConnection.query("INSERT INTO subcategories (CatId,SubCatName) VALUES"+'('+"'" +CatId+"'"+","+"'" +subcatName+"'"+')' , function(err, result){
            if(err) 
            {

                 res.send(err.message);
            }
           else 
           {
            console.log("Succefully Added") 
            res.redirect("/");

           }
               
            });  
       
});

app.get('/Product',(req,res,next)=>{

    mysqlConnection.query("Select * from categories",function(err,data1,field){
        if(err) throw(err);
        else
        {
            mysqlConnection.query("Select * from subcategories",function(err,data2,field){
                if(err) throw(err);
                else
                {
        
                    //console.log(data1);
                  //  console.log(data2);
                    res.render("product",{opt1:data1,opt2:data2})
                }
          
           })

            //res.render("product",{opt1:data1,opt2:data2})
        }
  
   })

//Add product page
app.post('/AddProduct',(req,res)=>{

    //var e = document.getElementById("catlist");
   // var result = e.options[e.selectedIndex].value;
    //console.log(result);
    //console.log(value);
  var CatId=req.body.catlist;

  var SubCatId=req.body.subcatlist;
  
  var productName=req.body.prodname;
  console.log(CatId);
  console.log(SubCatId);
  console.log(productName);
           // var subCatName=req.body.SubCategoryName


           mysqlConnection.query("INSERT INTO product (ProdName,SubId,CatId) VALUES"+'('+"'" +productName+"'"+","+"'" +SubCatId+"'"+","+"'" +CatId+"'"+')' , function(err, result){
            if(err) 
            {

                 res.send(err.message);
            }
           else 
           {
            console.log("Succefully Added") 
            res.redirect("/");

           }
               
            });  
       
});
//app.get('/upcat',function(req,res){

   //mysqlConnection.query("Select * from categories",function(err,data,field){
     //if(err) throw(err);
       //else
        

            //console.log(data);
          //  console.log(data2);
         //res.send("hi");
    //    res.sendFile(path.join(__dirname,"view.html"))
        //  res.render("UpdateCat",{opt:data})
        
          
  // })


//});
//End
/*app.get('/Catupdate',(req,res,next)=>{

    mysqlConnection.query("Select * from categories",function(err,data1,field){
        if(err) throw(err);
        else
        {
             res.render("UpdateCat",{opt:data1})
        }
          
    })

            //res.render("product",{opt1:data1,opt2:data2})
        
  
   });*/
/*app.post("/UpdateMainCategory",function(req,res){

    var CatId=req.body.catlist;
    var CatName=req.body.CatgName;


    mysqlConnection.query("UPDATE categories SET CatName = ? WHERE address = ?",[CatName,CatId],function(err,data,field){
        if(err) throw(err);
        else{
            res.send("Updated")
            console.log("Updated")
            }
    })
              
})
  */  
})





/*app.post('/loadSubcat',(req,res,next)=>{
    
    var CatId=req.body.catlist;

    mysqlConnection.query("select * from subcategories where CatId="+ mysql.escape(CatId),function(err,data,field){
        if(err) throw (err);
        else
        {
            console.log(data);
            res.render("product",{opt2:data})
        }
    })
})
mysqlConnection.query("Select * from categories",function(err,data,field){
     //if(err) throw(err);
    
})*/
app.post('/update',(req,res)=>{
    mysqlConnection.query("Select * from categories",function(err,data,field){
        if(err) throw (err);
        res.render("UpdateCat",{opt:data})
    })
    //res.sendFile(path.join(__dirname,'update.html'))
})
app.post('/UpdateMainCategory',(req,res)=>{
    //    else
    
        var CatId=req.body.catlist;
        var CatName=req.body.CatgName;
        console.log(CatId);
        console.log(CatName);
    
        

    mysqlConnection.query("UPDATE categories SET CatName="+"'"+CatName+"'"+"where CatId="+"'"+CatId+"'",function(err,data,field){
        if(err) throw err;
        console.log("Succefully Added") 
            res.redirect("/");
    
    })
})

app.get('/',function(req,res){res.sendFile(path.join(__dirname,'maincat.html'))})


app.listen(3000,function(err){
    if(!err){
        console.log("Connected");
    }
    else{
        console.log("Not Connected");
    }
})
 
app.get('/productlist', function (req,res) {
    mysqlConnection.query("select * from product",function(err,data,field){
        if(err) throw err;
        else console.log(data);
        res.send(data);
        
    })
    });
   

    app.post('/formaction', function (req,res) {
    
        
        var catName=req.body.CategoryName;
        
       // var subCatName=req.body.SubCategoryName
        mysqlConnection.query("INSERT INTO categories (CatName) VALUES"+'('+"'" +catName+"'"+')' , function(err, result){
            if(err) 
            {

                 res.send(err.message);
            }
           else 
           {
                            
            console.log("Successfully added")
            res.redirect('/');

           }
               
            });  
            

        
        });

/* GET home page. */
/*router.get('/', function (req, res) {

    mysqlConnection.connect(_config.dbConnection()).then(() => {
        return mysqlConnection.query`SELECT * FROM categories;`
    }).then(result => {
        // Pass the DB result to the template
        res.render('index', { dropdownVals: result.recordset })
    }).catch(err => {
        console.log(err)
    })

});*/


/*app.get('/listCatagories', function (req,res) {

    mysqlConnection.query("select * from categories",function(err,data,field){
        if(err) throw err;
       // else console.log(data);
       else
       {

        //console.log(data);
        var option = "";
        for(var i=0; i<data.length; i++)
        {
            //console.log(data[i].CatName);
           //console.log(data[i].CatId);
            option+= '<option value="'+ data[i].CatId +'">' + data[i].CatName + "</option>"
          
        }
        document.getElementById("maincat-dropdown").innerHTML = option;
       
       }
        // res.render('form', { dropdownVals: data.recordset })
        
    })
    });*/










app.get("/listproducts", (req,res,next) => {
    mysqlConnection.query("select * from product",function(err,data,field){
        if(err) throw err;
        res.render("productview",{opt:data})
        //console.log(data)
        
    })
});

app.post("/viewProduct", (req,res,next) => {

var prodId=req.body.products;

//console.log(prodId);
    mysqlConnection.query("select ProdName,CatName,SubCatName from product a join categories b on a.CatId=b.CatId join subcategories c on  a.SubId=c.SubId where ProdId="+"'"+prodId+"'",function(err,data,field){
        if(err) throw err;
       // res.render("productview",{opt:data})
        console.log(data[0].ProdName)
       // res.redirect("http://localhost:3000/"+data[0].CatName+"/"+data[0].SubCatName)
       // res.send(data[0].ProdName)

      // app.get("/:parent/:sub",function (req, res)
      // {
        //console.log(data[0].CatName)
       // console.log(req.params.CatName);
        //req.params.parent=data[0].CatName;
        //req.params.sub=data[0].SubCatName;
        //console.log(req.params.parent);
       // res.send(data[0].ProdName);

      // })
        
       res.redirect("http://localhost:3000/test/"+data[0].CatName+"/"+data[0].SubCatName+"/"+prodId)
       res.render("test",{result:data[0].ProdName})

    })
    
});/*
app.get("test/:parent/:sub", function (req, res) {
    var cat;
    var subcat;
    connection.query(
      "SELECT CatId FROM categories WHERE CatName =" +"'" +req.params.parent+ "'",
      function (err, rows, fields) {
        if (err) throw err;
        console.log(rows)
        cat=rows[0].CatId
        connection.query(
          "SELECT SubId FROM subcategories WHERE Catid =" +cat+" AND SubCatName ="+"'"+req.params.sub+ "'",
          function (err, rows2, fields) {
            if (err) throw err;
            subcat=rows2[0].SubId
            console.log(" subcat id = " +subcat)
            connection.query(
              "SELECT ProdId FROM product WHERE SubId =" +subcat,
              function (err, rows3, fields) {
                if (err) throw err;
                console.log(rows3)
               res.render("selectdemo",{opt2:rows3})
              }
            );
          }
        );
      }
    )
  });*/
  app.get('/test/:cat/:sub/:prod',function(req,res){
      
    console.log(req.params.prod)
    console.log(req.params.sub)
    console.log(req.params.cat)
        //mysqlConnection.query("Select ProdName from product where ProdId="+req.params.prod,function(err,data,field){
            mysqlConnection.query("select ProdName from product a join categories b on a.CatId=b.CatId join subcategories c on  a.SubId=c.SubId where ProdId="+"'"+req.params.prod+"'"+"and CatName="+"'"+req.params.cat+"'"+"and SubCatName="+"'"+req.params.sub+"'",function(err,data,field){
               console.log(data)
               console.log(data.length)
             if(data.length==0)
             {

                res.send("No products found!");
             }
             else
             {
                res.send(data[0].ProdName);
             }
    
              
            
           
        })
  })

