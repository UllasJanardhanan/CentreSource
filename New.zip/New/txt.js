const express = require("express");
const mysql = require("mysql");

const path = require("path");
var app = express();
var bodyParser = require('body-parser')
app.use( bodyParser.json() );       // to support JSON-encoded bodies
app.use(bodyParser.urlencoded({     // to support URL-encoded bodies
  extended: true
})); 
var connection= mysql.createPool({
  host: "localhost",
  user: "root",
  password: "123456",
  database: "db1",
})
  connection.connect();
app.get("/", function (req, res) {
  res.sendFile(path.join(__dirname, "form.html"));
});
app.post("/formaction", function (req, res) {
    console.log(req.body)
    var catName=req.body.CategoryName;
    
    var subCatName=req.body.SubCategoryName
    connection.query("INSERT INTO maincategories (Categoryid,categoryname,parntid) VALUES"+' (8,'+ catName+',2)' , function(err, result){
        if(err) throw err;
            console.log("1 Cat inserted");
        });  
        connection.query("Add your subcategory insert query"+ catName , function(err, result){
            if(err) throw err;
                console.log("1 subcat inserted");
            });  
  res.send("Product Added");
});
app.get("/Product", (req, res) => {
  res.send("Product Page");
});

app.listen(3000, function (err) {
  if (!err) {
    console.log("Connected");
  } else {
    console.log("Not Connected");
  }
});