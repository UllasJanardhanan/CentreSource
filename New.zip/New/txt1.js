var express = require("express");
var path = require("path");
var app = express();
var bodyParser = require('body-parser')
app.use( bodyParser.json() );       // to support JSON-encoded bodies
app.use(bodyParser.urlencoded({     // to support URL-encoded bodies
  extended: true
})); 
app.set("view engine", "pug");
app.set("views", path.join(__dirname, "views"));
var mysql = require("mysql");
var connection = mysql.createConnection({
  host: "localhost",
  user: "root",
  database: "category",
});

connection.connect();

app.get("/", function (req, res) {
  connection.query(
    "SELECT categoryname FROM maincategories ",
    function (err, rows, fields) {
      if (err) throw err;
      console.log(rows)
      res.render("selectdemo", {opt:rows});
    }
  );
});
app.get("/:parent", function (req, res) {
  var subcat;
  connection.query(
    "SELECT Categoryid FROM maincategories WHERE categoryname =" +"'" +req.params.parent+ "'",
    function (err, rows, fields) {
      if (err) throw err;
      console.log(rows)
      subcat=rows[0].Categoryid
      connection.query(
        "SELECT subcatname FROM subcat WHERE catid =" +subcat,
        function (err, rows2, fields) {
          if (err) throw err;
          console.log(rows2)
         res.render("selectdemo",{opt1:rows2})
        }
      );
    }
  )

});
app.get("/:parent/:sub", function (req, res) {
  var cat;
  var subcat;
  connection.query(
    "SELECT Categoryid FROM maincategories WHERE categoryname =" +"'" +req.params.parent+ "'",
    function (err, rows, fields) {
      if (err) throw err;
      console.log(rows)
      cat=rows[0].Categoryid
      connection.query(
        "SELECT subcatid FROM subcat WHERE catid =" +cat+" AND subcatname ="+"'"+req.params.sub+ "'",
        function (err, rows2, fields) {
          if (err) throw err;
          subcat=rows2[0].subcatid
          console.log(" subcat id = " +subcat)
          connection.query(
            "SELECT productname FROM product WHERE subid =" +subcat,
            function (err, rows3, fields) {
              if (err) throw err;
              console.log(rows3)
             res.render("selectdemo",{opt2:rows3})
            }
          );
        }
      );
    }
  )
});

app.listen(3001);